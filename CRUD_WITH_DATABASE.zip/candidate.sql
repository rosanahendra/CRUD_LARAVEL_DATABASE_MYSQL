-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2022 at 12:26 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `candidate`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `cand_id` bigint(20) UNSIGNED NOT NULL,
  `cand_name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cand_education` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cand_birthday` date NOT NULL,
  `cand_experience` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cand_last_position` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cand_applied_position` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cand_skill` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cand_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cand_resume` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `cand_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`cand_id`, `cand_name`, `cand_education`, `cand_birthday`, `cand_experience`, `cand_last_position`, `cand_applied_position`, `cand_skill`, `cand_phone`, `cand_resume`, `cand_email`, `created_at`, `updated_at`) VALUES
(1, 'smith a', 'UGM Yogyakarta', '1991-01-19', 'CEO', 'Senior PHP Developer', 'Laravel, Mysql, PostgreSQL, Codeigniter, Java', 'Laravel, Mysql, PostgreSQL, Codeigniter, Java', '085123456789', '', 'smith@gmail.com', NULL, '2022-06-03 21:34:38'),
(13, 'Farah', 'UPI', '1992-03-10', 'Marketing', 'sales', 'manager', 'PHP, HTML, CSS', '081321500111', NULL, 'farah@gmail.com', '2022-06-03 22:06:53', '2022-06-03 22:06:53'),
(14, 'Jokowi', 'ITB', '1992-03-10', 'presiden', 'presiden', 'menteri', 'PHP, HTML', '0811223344', NULL, 'joko@gmail.com', '2022-06-03 22:09:12', '2022-06-03 22:09:12'),
(15, 'hendra', 'UPI', '1992-03-10', 'sasas', 'Frontend', 'Web Developer', 'PHP, HTML', '081321500100', NULL, 'herosun@gmail.com', '2022-06-03 22:12:26', '2022-06-03 22:12:26'),
(16, 'Dodo', 'UPI', '1992-03-10', 'ased', 'sales', 'Web Developer', 'PHP, HTML, CSS', '081321500100', NULL, 'herosun@gmail.com', '2022-06-03 22:13:09', '2022-06-03 22:13:09'),
(17, 'Dodo', 'Telkom University', '1992-03-10', 'SAd', 'Frontend', 'Web Developer', 'PHP, HTML', '081321500100', NULL, 'herosun@gmail.com', '2022-06-03 22:13:36', '2022-06-03 22:13:36'),
(18, 'hendra', 'Telkom University', '1991-03-10', 'asdd', 'Frontend', 'Web Developer', 'PHP, HTML, CSS', '081321500100', NULL, 'herosunmicrosystem@gmail.com', '2022-06-03 22:15:43', '2022-06-03 22:15:43'),
(21, 'hendra rosana', 'Telkom University', '1992-03-10', 'dadad', 'Web Developer', 'Web Developer', 'PHP, HTML, CSS', '081321500100', NULL, 'herosun@gmail.com', '2022-06-05 00:14:35', '2022-06-05 00:14:43'),
(22, 'hendra', 'Telkom University', '1992-03-10', 'dadad', 'Frontend', 'manager', 'PHP, HTML', '081321500100', '1654416103_', 'Dadang@gmail.com', '2022-06-05 01:01:43', '2022-06-05 01:01:43'),
(23, 'Dodo bin dede', 'Telkom University', '1992-03-10', 'dadad', 'Frontend', 'Web Developer', 'PHP, HTML, CSS', '081321500100', NULL, 'herosunmicrosystem@gmail.com', '2022-06-05 01:23:16', '2022-06-05 02:50:28'),
(24, 'Dadang', 'UPI Teknik', '1992-03-10', 'kerja', 'Frontend', 'Web Developer', 'PHP, HTML', '081321500100', NULL, 'herosunmicrosystem@gmail.com', '2022-06-05 03:12:17', '2022-06-05 03:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`) VALUES
(1, 'Candidate');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(15, '2014_10_12_000000_create_users_table', 1),
(16, '2014_10_12_100000_create_password_resets_table', 1),
(17, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(18, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(19, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(20, '2016_06_01_000004_create_oauth_clients_table', 1),
(21, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usty_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `usty_id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Mr. John', 'john@gmail.com', NULL, '$2y$10$uH8ucRetyPNfBHZvT/wWruaoIb60UIxfgeZL1oWBr4czAvioW60.C', NULL, '2022-06-04 00:43:16', '2022-06-04 00:43:16'),
(2, 2, 'Mrs. Lee', 'lee@gmail.com', NULL, '$2y$10$G8JOr9iO86yUIZ5oZeyZQek/prQ871ojKY48OQ6lZji5WSe9d4PVG', NULL, '2022-06-04 19:06:36', '2022-06-04 19:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `usac_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `usty_id` int(11) NOT NULL,
  `usac_create` enum('Inaccessible','Accessible') NOT NULL,
  `usac_read` enum('Inaccessible','Accessible') NOT NULL,
  `usac_view` enum('Inaccessible','Accessible') NOT NULL,
  `usac_update` enum('Inaccessible','Accessible') NOT NULL,
  `usac_delete` enum('Inaccessible','Accessible') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`usac_id`, `menu_id`, `usty_id`, `usac_create`, `usac_read`, `usac_view`, `usac_update`, `usac_delete`) VALUES
(1, 1, 1, 'Accessible', 'Accessible', 'Accessible', 'Accessible', 'Accessible'),
(2, 1, 2, 'Inaccessible', 'Accessible', 'Accessible', 'Inaccessible', 'Inaccessible');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `usty_id` int(11) NOT NULL,
  `usty_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`usty_id`, `usty_name`) VALUES
(1, 'Senior HRD'),
(2, 'HRD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`cand_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_access`
--
ALTER TABLE `user_access`
  ADD PRIMARY KEY (`usac_id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`usty_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `cand_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_access`
--
ALTER TABLE `user_access`
  MODIFY `usac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `usty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

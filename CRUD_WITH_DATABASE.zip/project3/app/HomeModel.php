<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeModel extends Model
{
    protected $table = 'candidate';
    protected $fillable = ['title'];
    protected $primaryKey = 'cand_id';
	
    protected $hidden = [
        'password', 'remember_token',
    ];
	
	/** @OA\Schema(
     *     schema="Candidate",
     *     required={"cand_id", "cand_name", "cand_education", "cand_birthday", "cand_experience", "cand_last_position", "cand_applied_position", "cand_skill", "cand_phone", "cand_resume", "cand_email", "created_at", "updated_at"},
     *     @OA\Property(
     *         property="cand_id",
     *         type="integer",
     *         format="int32"
     *     ),
     *     @OA\Property(
     *         property="cand_name",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_education",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_birthday",
     *         type="string",
     *         format="date-time"
     *     ),
     *     @OA\Property(
     *         property="cand_experience",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_last_position",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_applied_position",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_skill",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_phone",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_resume",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="cand_email",
     *         type="string"
     *     ),
     *     @OA\Property(
     *         property="created_at",
     *         type="string",
     *         format="date-time"
     *     ),
     *     @OA\Property(
     *         property="updated_at",
     *         type="string",
     *         format="date-time"
     *     )
     * ),
     */
}

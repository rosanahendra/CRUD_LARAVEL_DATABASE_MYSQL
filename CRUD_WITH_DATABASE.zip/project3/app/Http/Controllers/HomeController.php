<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\HomeModel;
use Auth;
use Illuminate\Http\UploadFile;
use File;
use Illuminate\Support\Facades\Storage;
use DB;
use App\Http\Requests\HomeRequest;
//use App\Repositories\ProductRepository;
//use App\Repositories\ResponseRepository;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
	 
    public function index()
    {
		$menu_id = 1;
		$user_type = Auth::user()->usty_id;
		$access = DB::table('user_access')
			->select('*')
			->where('menu_id', $menu_id)
			->where('usty_id', $user_type)
			->get();
		
		$candidate = HomeModel::all()->sortByDesc('cand_id');
		$pagination = HomeModel::orderBy('cand_id', 'desc')->paginate(2);
		$count = $candidate->count('cand_id');
		$page = 'home';
		return view('home', compact('candidate', 'count', 'pagination', 'access'));
    }

    public function show($cand_id){
        $data = HomeModel::where('cand_id', $cand_id)->firstOrFail();
        return view('form', compact('data'));
    }

    public function showView($cand_id){
        $data = HomeModel::where('cand_id', $cand_id)->firstOrFail();
        return view('view', compact('data'));
    }
	
    public function create(){
        return view('form');
    }
    
	/**
     * @OA\Post(
     *     path="/Home",
     *     tags={"candidate"},
     *     summary="Add a new Candidate to the store",
     *     description="Returns a single new user.",
     *     operationId="createCandidate",
     *     @OA\RequestBody(
     *          description= "Candidate object that needs to be added to the store",
     *          required=true,
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="cand_name", type="string"),
     *              @OA\Property(property="cand_education", type="string"),
     *              @OA\Property(property="cand_birthday", type="string"),
     *              @OA\Property(property="cand_experience", type="string"),
     *              @OA\Property(property="cand_last_position", type="string"),
     *              @OA\Property(property="cand_applied_position", type="string"),
     *              @OA\Property(property="cand_skill", type="string"),
     *              @OA\Property(property="cand_phone", type="string"),
     *              @OA\Property(property="cand_email", type="string")
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *         @OA\JsonContent(ref="#/components/schemas/Candidate"),
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid id supplied",
     *         @OA\JsonContent(
     *              type="object",
     *              @OA\Property(
     *                  property="message",
     *                  type="string",
     *                  example="The specified data is invalid."
     *              ),
     *              @OA\Property(
     *                  property="errors",
     *                  type="object",
     *                  example={
     *                      "name": "The name field is required.",
     *                  },
     *              ),
     *         ),
     *     ),
     * )
     */
	
    public function store(HomeRequest $request){
        /*
		$data = $request->all();
        $candidate = HomeModel::create($data);
        new UserResource($candidate);
		*/
		
		$row = new HomeModel;
        $row->cand_name = $request->cand_name;
        $row->cand_education = $request->cand_education;
        $row->cand_birthday = $request->cand_birthday;
        $row->cand_experience = $request->cand_experience;
        $row->cand_last_position = $request->cand_last_position;
        $row->cand_applied_position = $request->cand_applied_position;
        $row->cand_skill = $request->cand_skill;
        $row->cand_phone = $request->cand_phone;
        $row->cand_email = $request->cand_email;
		
		/*$image = $request->file('cand_resume');
		$ext = pathinfo($image, PATHINFO_EXTENSION);
        $image_name = time().'.'.$image.$ext;
        $destinationPath = base_path('public/foto');
        $image->move($destinationPath, $image_name);
     	$row->cand_resume = $request->file('cand_resume');
        ///$size = $gambar_barang->getSize();
		
		
		/*
		$photo = $request->file('file');
		$name = sha1(date('YmdHis') . str_random(30));
		$save_name = $name . '.' . $photo->getClientOriginalExtension(); // this is line 198
		$resize_name = $name . str_random(2) . '.' . $photo->getClientOriginalExtension();
		$path = 'foto';
		
		Image::make($photo)
			->resize(250, null, function ($constraints) {
				$constraints->aspectRatio();
			})
			->save($path . '/' . $resize_name);

		$photo->move($path, $save_name);
		$upload->cand_resume = $save_name;
		*/
		$row->save();
        return redirect('index');
    }
    
    public function edit($cand_id, HomeRequest $request){
        $row = HomeModel::where('cand_id', $cand_id)->firstOrFail();
        $row->cand_name = $request->cand_name;
        $row->cand_education = $request->cand_education;
        $row->cand_birthday = $request->cand_birthday;
        $row->cand_experience = $request->cand_experience;
        $row->update($request->all());
        return redirect('index');
    }
    
    public function delete($cand_id, Request $request){
        $row = HomeModel::where('cand_id', $cand_id)->firstOrFail();
        $row->delete($request->all());
        return redirect('index');
    }
}

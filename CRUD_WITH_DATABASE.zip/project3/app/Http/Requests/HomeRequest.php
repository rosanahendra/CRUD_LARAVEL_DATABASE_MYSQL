<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class HomeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cand_name' => 'required|string',
            'cand_education' => 'required|string',
            'cand_birthday' => 'required|date',
            'cand_experience' => 'required|string',
            'cand_last_position' => 'required|string',
            'cand_applied_position' => 'required|string',
            'cand_skill' => 'required|string',
            'cand_phone' => 'required|numeric',
            'cand_email' => 'required|string',
        ];
    }
}

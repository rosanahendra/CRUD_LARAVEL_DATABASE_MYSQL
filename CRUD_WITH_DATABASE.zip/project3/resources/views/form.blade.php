@extends('layouts.app')

@section('content')
<form action="@if(!empty($data)) {{url('home/'.$data->cand_id.'/edit')}} @else {{url('home/store')}} @endif" method="@if(!empty($data)) get @else get @endif" aria-label="{{ __('Upload') }}" enctype="multipart/form-data">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center" id="title-form"><h3>Form Candidate</h3></div>
			<div class="col-md-6">
				@csrf
				@method('PATCH')
				<div class="form-group">
					<label class="label">Name</label>
					<input type="input" name="cand_name" placeholder="Name" value="@if(!empty($data)) {{ $data->cand_name }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Education</label>
					<input type="text" name="cand_education" placeholder="Education" value="@if(!empty($data)) {{ $data->cand_education }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Birthday</label>
					<input type="text" name="cand_birthday" placeholder="Birthday" value="@if(!empty($data)) {{ $data->cand_birthday }} @endif" class="form-control datepicker">
				</div>
				<div class="form-group">
					<label class="label">Experience</label>
					<textarea name="cand_experience" style="resize:none; height:205px;" class="form-control">@if(!empty($data)) {{ $data->cand_experience }} @endif</textarea>
				</div>
			</div>	
			<div class="col-md-6">	
				<div class="form-group">
					<label class="label">Last Position</label>
					<input type="text" name="cand_last_position" placeholder="Last Position" value="@if(!empty($data)) {{ $data->cand_applied_position }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Applied Position</label>
					<input type="text" name="cand_applied_position" placeholder="Applied Position" value="@if(!empty($data)) {{ $data->cand_applied_position }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Top 5 Skills</label>
					<input type="text" name="cand_skill" placeholder="Top 5 Skills" value="@if(!empty($data)) {{ $data->cand_skill }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Email</label>
					<input type="email" name="cand_email" placeholder="Email" value="@if(!empty($data)) {{ $data->cand_email }} @endif" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Phone</label>
					<input type="text" name="cand_phone" placeholder="Phone" value="@if(!empty($data)) {{ $data->cand_phone }} @endif" class="form-control">
				</div>
				<!--
				<div class="form-group">
					<label class="label">Resume in PDF</label>
					<input type="file" name="cand_resume" placeholder="Resume in PDF" class="form-control">
				</div>
				-->
			</div>
			<div class="col-md-12 text-center">		
				<div class="form-group">
					<input type="submit" name="simpan" class="btn btn-primary">
					<a href="{{ url('home') }}" class="btn btn-danger">Back</a>
				</div> 
			</div>   
		</div>
	</div>
</form>
@endsection
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
				<?php
				foreach($access as $row2):
					$create = $row2->usac_create;
					$read = $row2->usac_read;
					$view = $row2->usac_view;
					$update = $row2->usac_update;
					$delete = $row2->usac_delete;
				endforeach;
				?>
                <div class="card-header"><font class="title">CRUD Data Candidate</font> <?php if($create == 'Accessible'){ ?><font class="create"><a href="{{ url('home/create') }}" class="btn btn-success">Create Data</a></font><?php } ?></div>
				<div class="card-body">
					<div>
						<table class="table">
							<tr>
								<th>No.</th>
								<th>Name</th>
								<th>Education</th>
								<th>Birthday</th>
								<th>Experience</th>
								<th>Action</th>
							</tr>
							<?php 
							$i = 1;
							foreach($candidate as $row):
							?>
							<tr>
								<td>{{ $i }}</td>
								<td>{{ $row->cand_name }}</td>
								<td>{{ $row->cand_education }}</td>
								<td>{{ $row->cand_birthday }}</td>
								<td>{{ $row->cand_experience }}</td>
								<td>
									<?php if($view == 'Accessible'){ ?><a href="{{ url('homeView/'.$row->cand_id) }}" class="btn btn-primary">View</a><?php } ?> <?php if($update == 'Accessible'){ ?><a href="{{ url('home/'.$row->cand_id) }}" class="btn btn-warning">Edit</a><?php } ?> <?php if($delete == 'Accessible'){ ?><a href="{{ url('home/'.$row->cand_id.'/delete') }}" class="btn btn-danger" onclick="return confirmation();">Delete</a><?php } ?>
								</td>
							</tr>
							<?php $i++; endforeach ?>
						</table>
					</div>
				</div>
				<div>Jumlah Data : {{ $count }}</div>
            </div>
        </div>
    </div>
</div>
@endsection

<script>
    function confirmation(){
        var txt;
        var r = confirm('Are You sure to delete this data ?');	
        if (r == true) {
            txt = "You pressed OK!";
        return true;
        } else {
            txt = "You pressed Cancel!";
        return false;
        }
    }
</script>

@extends('layouts.app')

@section('content')
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center" id="title-form"><h3>View Candidate</h3></div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="label">Name</label>
					<div>@if(!empty($data)) {{ $data->cand_name }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Education</label>
					<div>@if(!empty($data)) {{ $data->cand_education }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Birthday</label>
					<div>@if(!empty($data)) {{ $data->cand_birthday }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Experience</label>
					<div>@if(!empty($data)) {{ $data->cand_experience }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Last Position</label>
					<div>@if(!empty($data)) {{ $data->cand_applied_position }} @endif</div>
				</div>
			</div>	
			<div class="col-md-6">	
				<div class="form-group">
					<label class="label">Applied Position</label>
					<div>@if(!empty($data)) {{ $data->cand_applied_position }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Top 5 Skills</label>
					<div>@if(!empty($data)) {{ $data->cand_skill }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Email</label>
					<div>@if(!empty($data)) {{ $data->cand_email }} @endif</div>
				</div>
				<div class="form-group">
					<label class="label">Phone</label>
					<div>@if(!empty($data)) {{ $data->cand_phone }} @endif</div>
				</div>
				<!--
				<div class="form-group">
					<label class="label">Resume in PDF</label>
					<input type="file" name="cand_resume" placeholder="Resume in PDF" class="form-control">
				</div>
				-->
			</div> 
			<div class="col-md-12 text-center">		
				<div class="form-group">
					<a href="{{ url('home') }}" class="btn btn-danger">Back</a>
				</div> 
			</div>   
		</div>
	</div>
</form>
@endsection
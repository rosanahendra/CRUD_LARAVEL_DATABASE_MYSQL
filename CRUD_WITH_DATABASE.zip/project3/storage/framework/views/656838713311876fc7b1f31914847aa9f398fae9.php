<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
				<?php
				foreach($access as $row2):
					$create = $row2->usac_create;
					$read = $row2->usac_read;
					$view = $row2->usac_view;
					$update = $row2->usac_update;
					$delete = $row2->usac_delete;
				endforeach;
				?>
                <div class="card-header"><font class="title">CRUD Data Candidate</font> <?php if($create == 'Accessible'){ ?><font class="create"><a href="<?php echo e(url('home/create')); ?>" class="btn btn-success">Create Data</a></font><?php } ?></div>
				<div class="card-body">
					<div>
						<table class="table">
							<tr>
								<th>No.</th>
								<th>Name</th>
								<th>Education</th>
								<th>Birthday</th>
								<th>Experience</th>
								<th>Action</th>
							</tr>
							<?php 
							$i = 1;
							foreach($candidate as $row):
							?>
							<tr>
								<td><?php echo e($i); ?></td>
								<td><?php echo e($row->cand_name); ?></td>
								<td><?php echo e($row->cand_education); ?></td>
								<td><?php echo e($row->cand_birthday); ?></td>
								<td><?php echo e($row->cand_experience); ?></td>
								<td>
									<?php if($view == 'Accessible'){ ?><a href="<?php echo e(url('homeView/'.$row->cand_id)); ?>" class="btn btn-primary">View</a><?php } ?> <?php if($update == 'Accessible'){ ?><a href="<?php echo e(url('home/'.$row->cand_id)); ?>" class="btn btn-warning">Edit</a><?php } ?> <?php if($delete == 'Accessible'){ ?><a href="<?php echo e(url('home/'.$row->cand_id.'/delete')); ?>" class="btn btn-danger" onclick="return confirmation();">Delete</a><?php } ?>
								</td>
							</tr>
							<?php $i++; endforeach ?>
						</table>
					</div>
				</div>
				<div>Jumlah Data : <?php echo e($count); ?></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    function confirmation(){
        var txt;
        var r = confirm('Are You sure to delete this data ?');	
        if (r == true) {
            txt = "You pressed OK!";
        return true;
        } else {
            txt = "You pressed Cancel!";
        return false;
        }
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel\project3\resources\views/home.blade.php ENDPATH**/ ?>
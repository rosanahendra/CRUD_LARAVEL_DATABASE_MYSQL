<?php $__env->startSection('content'); ?>
<form action="<?php if(!empty($data)): ?> <?php echo e(url('home/'.$data->cand_id.'/edit')); ?> <?php else: ?> <?php echo e(url('home/store')); ?> <?php endif; ?>" method="<?php if(!empty($data)): ?> get <?php else: ?> get <?php endif; ?>" aria-label="<?php echo e(__('Upload')); ?>" enctype="multipart/form-data">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center" id="title-form"><h3>Form Candidate</h3></div>
			<div class="col-md-6">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PATCH'); ?>
				<div class="form-group">
					<label class="label">Name</label>
					<input type="input" name="cand_name" placeholder="Name" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_name); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Education</label>
					<input type="text" name="cand_education" placeholder="Education" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_education); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Birthday</label>
					<input type="text" name="cand_birthday" placeholder="Birthday" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_birthday); ?> <?php endif; ?>" class="form-control datepicker">
				</div>
				<div class="form-group">
					<label class="label">Experience</label>
					<textarea name="cand_experience" style="resize:none; height:205px;" class="form-control"><?php if(!empty($data)): ?> <?php echo e($data->cand_experience); ?> <?php endif; ?></textarea>
				</div>
			</div>	
			<div class="col-md-6">	
				<div class="form-group">
					<label class="label">Last Position</label>
					<input type="text" name="cand_last_position" placeholder="Last Position" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_applied_position); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Applied Position</label>
					<input type="text" name="cand_applied_position" placeholder="Applied Position" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_applied_position); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Top 5 Skills</label>
					<input type="text" name="cand_skill" placeholder="Top 5 Skills" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_skill); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Email</label>
					<input type="email" name="cand_email" placeholder="Email" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_email); ?> <?php endif; ?>" class="form-control">
				</div>
				<div class="form-group">
					<label class="label">Phone</label>
					<input type="text" name="cand_phone" placeholder="Phone" value="<?php if(!empty($data)): ?> <?php echo e($data->cand_phone); ?> <?php endif; ?>" class="form-control">
				</div>
				<!--
				<div class="form-group">
					<label class="label">Resume in PDF</label>
					<input type="file" name="cand_resume" placeholder="Resume in PDF" class="form-control">
				</div>
				-->
			</div>
			<div class="col-md-12 text-center">		
				<div class="form-group">
					<input type="submit" name="simpan" class="btn btn-primary">
					<a href="<?php echo e(url('home')); ?>" class="btn btn-danger">Back</a>
				</div> 
			</div>   
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel\project3\resources\views/form.blade.php ENDPATH**/ ?>
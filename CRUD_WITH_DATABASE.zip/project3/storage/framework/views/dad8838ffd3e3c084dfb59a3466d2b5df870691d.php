<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center" id="title-form"><h3>View Candidate</h3></div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="label">Name</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_name); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Education</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_education); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Birthday</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_birthday); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Experience</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_experience); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Last Position</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_applied_position); ?> <?php endif; ?></div>
				</div>
			</div>	
			<div class="col-md-6">	
				<div class="form-group">
					<label class="label">Applied Position</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_applied_position); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Top 5 Skills</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_skill); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Email</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_email); ?> <?php endif; ?></div>
				</div>
				<div class="form-group">
					<label class="label">Phone</label>
					<div><?php if(!empty($data)): ?> <?php echo e($data->cand_phone); ?> <?php endif; ?></div>
				</div>
				<!--
				<div class="form-group">
					<label class="label">Resume in PDF</label>
					<input type="file" name="cand_resume" placeholder="Resume in PDF" class="form-control">
				</div>
				-->
			</div> 
			<div class="col-md-12 text-center">		
				<div class="form-group">
					<a href="<?php echo e(url('home')); ?>" class="btn btn-danger">Back</a>
				</div> 
			</div>   
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel\project3\resources\views/view.blade.php ENDPATH**/ ?>